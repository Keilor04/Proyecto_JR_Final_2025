console.log(`Funcionando Archivo: Practica_IF`);
