console.log('Funcionando Archivo: API_VerUsuario');

const Api_Usuarios = "https://randomuser.me/api/"